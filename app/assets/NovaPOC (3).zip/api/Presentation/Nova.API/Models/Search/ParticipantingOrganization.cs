﻿namespace Nova.API.Models.Search
{
    public class ParticipantingOrganization
    {
        public string Name { get; set; } = null!;
    }
}
