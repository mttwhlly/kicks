﻿namespace Nova.API.Models.Search
{
    public class Specialty
    {
        public string Name { get; set; } = null!;
    }
}
